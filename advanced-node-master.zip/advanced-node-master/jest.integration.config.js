module.exports = {
  ...require('./jest.config.js'),
  testMatch: ['**/*.test.ts']
}
