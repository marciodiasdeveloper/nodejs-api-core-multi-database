export const AccessToken = {
  expirationInMs: 30 * 60 * 1000
}
